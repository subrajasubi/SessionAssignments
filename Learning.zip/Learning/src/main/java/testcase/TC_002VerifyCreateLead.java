package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_002VerifyCreateLead extends BaseClass{

	@BeforeTest
	public void setVlaues() {
		ExcelFilename="CreateLeadExcel";

	}

	@Test(dataProvider = "sendData")
	public void runVerifyLogin(String cName,String fName,String lName) {
		new LoginPage().enterUsername().enterPassword().clickLoginButton().verifyHomepage()
		.clickCrmsfaLink().clickLeadLink().clickCreateLeadLink().
		enterCompanyName(cName).enterFirtsName(fName)
		.enterLastName(lName).clickCreateLeadButton().verifyViewLeadsPage(cName);
		;

	}
}
