package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcel;

public class BaseClass {

	public  static RemoteWebDriver driver;
	public static Properties prop1;
	public String ExcelFilename;

	@BeforeMethod
	public void preCondition() throws IOException {
		FileInputStream fis = new FileInputStream("src/test/resources/config.properties");
		Properties prop = new Properties();
		prop.load(fis);
		String browser = prop.getProperty("BROWSER");
		System.out.println(browser);
		String language = prop.getProperty("lANGUAGE");
		System.out.println(language);
		FileInputStream fis1= new FileInputStream("src/test/resources/"+language+".properties");
		prop1 = new Properties();
		prop1.load(fis1);
		
		if (browser.equalsIgnoreCase("chrome")) {
			driver=new ChromeDriver();	
		}
		else if (browser.equalsIgnoreCase("edge")) {
			driver=new EdgeDriver();
		}
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@AfterMethod
	public void postCondition() {
		driver.quit();

	}

	@DataProvider
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcel(ExcelFilename);

	}
	

}
