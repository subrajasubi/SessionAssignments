package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class WelcomePage extends BaseClass{
	
	public WelcomePage verifyHomepage() {
        String title = driver.getTitle();
        if (title.contains("Leaftaps")) {
			System.out.println("HomePage is Displayed");
		}
        else {
       	 System.out.println("HomePage is not displayed");
        }
       return this;
	}
	
	    public MyHompage clickCrmsfaLink() {
	    	driver.findElement(By.linkText("CRM/SFA")).click();
	    	return new MyHompage();
	    	
		}
	    

}
