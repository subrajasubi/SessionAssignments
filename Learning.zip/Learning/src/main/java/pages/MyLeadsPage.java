package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class MyLeadsPage extends BaseClass{
	
	public CreateLeadPage clickCreateLeadLink() {
		String CreateLeadLink = prop1.getProperty("MyLeadsPage.CreateLead.LinkText");
    	driver.findElement(By.linkText(CreateLeadLink)).click();
    	return new CreateLeadPage();
    	
   	}
}
