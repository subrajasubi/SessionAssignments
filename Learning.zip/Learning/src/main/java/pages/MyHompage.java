package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class MyHompage extends BaseClass{
	
	public MyLeadsPage clickLeadLink() {
		String LeadsLink = prop1.getProperty("MyHomePage.Leads.LinkText");
    	driver.findElement(By.linkText(LeadsLink)).click();
    	return new MyLeadsPage();
    	
   	}

}
