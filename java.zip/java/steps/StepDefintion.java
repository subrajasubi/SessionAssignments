package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefintion {
	public ChromeDriver driver;
@Given("Open browser")
	public void openBrowser() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}
@Given("Load url")
	public void load() {
		driver.get("http://leaftaps.com/opentaps/control/main");

	}
@Given("Enter username as {string}")
	public void user(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);

	}
@Given("Enter password as {string}")
	public void pass(String pWord) {
		driver.findElement(By.id("password")).sendKeys(pWord);

	}
@When("Click on Login button")
	public void logn() {
		driver.findElement(By.className("decorativeSubmit")).click();

	}
@Then("Homepage should be displayed")
	public void homepage() {
       System.out.println("Hompeage");

	}
@But("errorpage should be displayed")
public void errorpage() {
   System.out.println("error");

}



@When("Click crmsfa link")
public void clickcrms() {
	driver.findElement(By.linkText("CRM/SFA")).click();

}
@When("Click Lead button")
public void clickLead() {
	
	driver.findElement(By.linkText("Leads")).click();
}
@When("Click CreateLead link")
public void clickCreateLead() {
	driver.findElement(By.linkText("Create Lead")).click();

}
@When("Enter cname as (.*)$")
public void entercname(String cName) {
	driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);

}
@When("Enter fname as (.*)$")
public void enterfname(String fName) {
	driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);

}
@When("enter lname as (.*)$")
public void enterlasname(String lName) {
	driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);

}
@When("Click CreateLead button")
public void clickCreateLeadbutton() {
	driver.findElement(By.name("submitButton")).click();

}@When("ViewLeadsPage should be displayed")
public void viewleadspage() {
	String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
	if (text.contains("Testleaf")) {
		System.out.println("Lead created successfully");
	} else {
		System.out.println("Lead is not created");
	}
}
	@Then("close the browser")
	public void close() {
		driver.close();
	}

}




